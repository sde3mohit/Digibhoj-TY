# DigiBhoj — Temporary Login Credentials

These accounts are created by the demo seed script (`backend/seed.py`) for local development and testing only. **Do not use these credentials in production.**

## Shared password

| Field | Value |
|-------|-------|
| **Password** | `pass123` |

All seeded users share this password.

## Login URL

After starting the app:

```bash
uvicorn backend.main:app --reload
```

Open: **http://127.0.0.1:8000/login**

Use **email** as the username field and the password above.

---

## Accounts by role

### Admin

| Name | Email | Dashboard after login |
|------|-------|------------------------|
| DigiBhoj Admin | `admin@digibhoj.com` | `/admin/dashboard` |

### Customer

| Name | Email | Phone |
|------|-------|-------|
| Rahul Sharma | `rahul@test.com` | 9876543210 |
| Priya Patel | `priya@test.com` | 9876543211 |
| Amit Verma | `amit@test.com` | 9876543212 |

**Dashboard:** `/customer/home`

### Provider (mess owner)

| Mess name | Owner | Email |
|-----------|-------|-------|
| Sharma Tiffin Service | Ravi Sharma | `provider1@test.com` |
| Royal Kitchen | Suresh Kumar | `provider2@test.com` |
| Ghar Ka Khana | Sunita Devi | `provider3@test.com` |
| Punjabi Dhaba | Harpreet Singh | `provider4@test.com` |

**Dashboard:** `/provider/dashboard`

### Delivery agent

| Name | Email | Vehicle |
|------|-------|---------|
| Rajesh Driver | `delivery1@test.com` | Bike |
| Sunil Moto | `delivery2@test.com` | Scooter |
| Pankaj Rider | `delivery3@test.com` | Bike |

**Dashboard:** `/delivery/dashboard`

---

## How to load demo data

From the project root:

```bash
python -m backend.seed
```

This **drops and recreates** all tables, then inserts demo users, meals, orders, and assignments.

On **Vercel**, the app auto-seeds an empty database on startup (see `backend/main.py`).

---

## Quick reference

```
Password: pass123

Admin:     admin@digibhoj.com
Customer:  rahul@test.com | priya@test.com | amit@test.com
Provider:  provider1@test.com | provider2@test.com | provider3@test.com | provider4@test.com
Delivery:  delivery1@test.com | delivery2@test.com | delivery3@test.com
```

---

## Security note

These credentials are for **development and demos only**. Before deploying to production:

1. Change or remove seeded accounts.
2. Use strong, unique passwords.
3. Never commit real user passwords or secrets to the repository.
